package com.android.chienfx.cxfactor.login;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.android.chienfx.core.IntentCode;
import com.android.chienfx.core.MyHelper;
import com.android.chienfx.cxfactor.MainActivity;
import com.android.chienfx.cxfactor.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity{
    TabAdapter tabAdapter;
    TabLayout tabLayout;
    ViewPager viewPager;

    LoginFragment fmLogin;
    SignupFragment fmSignUp;

    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        auth = FirebaseAuth.getInstance();

        tabLayout = findViewById(R.id.tabLayout);
        viewPager = findViewById(R.id.viewPaper);

        tabAdapter = new TabAdapter(getSupportFragmentManager());

        fmLogin = new LoginFragment(this);
        fmSignUp = new SignupFragment(this);

        tabAdapter.addFragment(fmLogin, "Login");
        tabAdapter.addFragment(fmSignUp, "Sign Up");

        viewPager.setAdapter(tabAdapter);
        tabLayout.setupWithViewPager(viewPager);

        //setTabShowLoginFragment();
        setTabShowSignUpFragment();
    }

    void setTabShowLoginFragment(){
        this.viewPager.setCurrentItem(0);
    }
    void setTabShowSignUpFragment(){
        this.viewPager.setCurrentItem(1);
    }


    @Override
    public void finishActivity(int requestCode) {
        super.finishActivity(requestCode);
    }

    void finishLoginActivity(int resultCode, Object extraData) {
        Intent resultLoginIntent = new Intent();
        //put login access tokent to intent
        switch (resultCode){
            case IntentCode.RESULT_LOGIN_SUCCESSFUL:
                if(extraData!=null)
                    resultLoginIntent.putExtra("AccessToken", (String)extraData);
                break;
        }

        setResult(resultCode, resultLoginIntent);
        finish();

    }


    public void createUserWithEmailAndPasswor(String strEmail, final String strPassword) {
        auth.createUserWithEmailAndPassword(strEmail, strPassword)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        fmSignUp.progressBar.setVisibility(View.GONE);
                        if (!task.isSuccessful()) {
                            // there was an error
                            Toast.makeText(getApplicationContext(), getString(R.string.auth_failed), Toast.LENGTH_LONG).show();
                        } else {
                            MyHelper.toast(getApplicationContext(), "Register done! Login again!");
                            fmSignUp.clearSignFields();
                            setTabShowLoginFragment();
                        }
                    }
                });
    }

    public void loginWithEmailAndPassword(String strUsername, String strPassword) {
        auth.signInWithEmailAndPassword(strUsername, strPassword)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(!task.isSuccessful()){
                            MyHelper.toast(getApplicationContext(), "Login failed. Check your email and password!");
                        }
                        else
                        {
                            finishLoginActivity(IntentCode.RESULT_LOGIN_SUCCESSFUL, "Login successful!");
                        }
                    }
                });
    }
}
