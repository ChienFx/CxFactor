package com.android.chienfx.cxfactor.login;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.android.chienfx.core.MyHelper;
import com.android.chienfx.cxfactor.R;

@SuppressLint("ValidFragment")
public class SignupFragment extends Fragment implements View.OnClickListener {
    private Login loginInstance;
    protected View mViewInstance;
    protected EditText edEmai, edPassword, edPasswordConfirm;
    protected Button btnRegister;
    protected TextView tvTerm;
    protected CheckBox ckbAgreeTerm;
    protected String strPassword, strEmail, strConfirmPassword;

    protected ProgressBar progressBar;

    @SuppressLint("ValidFragment")
    public SignupFragment(Login login) {
        this.loginInstance = login;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        this.mViewInstance =   inflater.inflate(R.layout.signup_fragment, container, false);
        return mViewInstance;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        edEmai = (EditText)mViewInstance.findViewById(R.id.edSignUpEmail);
        edPassword = (EditText)mViewInstance.findViewById(R.id.edSignUpPassword);
        edPasswordConfirm = (EditText)mViewInstance.findViewById(R.id.edSignUpPasswordConfirm);

        tvTerm = (TextView)mViewInstance.findViewById(R.id.tvTermPolicy);
        ckbAgreeTerm = (CheckBox)mViewInstance.findViewById(R.id.ckbAgreeTerm);
        btnRegister = (Button)mViewInstance.findViewById(R.id.btnRegister);
        btnRegister.setEnabled(false);
        btnRegister.setOnClickListener(this);
        ckbAgreeTerm.setOnClickListener(this);
        tvTerm.setOnClickListener(this);
        progressBar = mViewInstance.findViewById(R.id.progressBarSignUp);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.ckbAgreeTerm:
                if(ckbAgreeTerm.isChecked())
                    btnRegister.setEnabled(true);
                else
                    btnRegister.setEnabled(false);
                break;
            case R.id.btnRegister:
                //do something here
                strEmail = edEmai.getText().toString().trim();
                strPassword = edPassword.getText().toString().trim();
                strConfirmPassword = edPasswordConfirm.getText().toString().trim();

                //register here
                if (TextUtils.isEmpty(strEmail)) {
                    MyHelper.toast(getContext(), "Enter email address!");
                    return;
                }

                if (strPassword.length() < 6) {
                    MyHelper.toast(getContext(), "Password too short, enter minimum 6 characters!");
                    return;
                }

                if(strPassword.compareTo(strConfirmPassword)!=0){
                    MyHelper.toast(getContext(), "Confirm Password is not match!");
                    return;
                }

                progressBar.setVisibility(View.VISIBLE);
                loginInstance.createUserWithEmailAndPasswor(strEmail, strPassword);

                ///clearSignFields();
                break;
        }
    }

    void clearSignFields() {
        edEmai.setText("");
        edPassword.setText("");
        edPasswordConfirm.setText("");
    }
}
