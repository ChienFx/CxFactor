package com.android.chienfx.cxfactor.login;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.method.LinkMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.android.chienfx.core.IntentCode;
import com.android.chienfx.core.MyHelper;
import com.android.chienfx.cxfactor.R;

@SuppressLint("ValidFragment")
public class LoginFragment extends Fragment implements View.OnClickListener {
    View viewInstance;
    Login loginInstance;
    TextView tvForgotPassword;
    TextView tvTerm;
    Button btnLogin;
    RelativeLayout relLoginWithFacebook, relLoginWithGoogle;
    EditText edUsername, edPassword;

    String strUsername, strPassword;

    @SuppressLint("ValidFragment")
    public LoginFragment(Login login) {
        this.loginInstance = login;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        viewInstance = inflater.inflate(R.layout.login_fragment, container, false);
        return viewInstance;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        tvForgotPassword =  viewInstance.findViewById(R.id.tvForgotPassword);
        tvTerm = viewInstance.findViewById(R.id.tvTermPolicy);
        btnLogin = viewInstance.findViewById(R.id.btnLogin);
        //btnLogin.setEnabled(false);
        relLoginWithFacebook = viewInstance.findViewById(R.id.relLoginWithFacebook);
        relLoginWithGoogle = viewInstance.findViewById(R.id.relLoginWithGoogle);
        edUsername = viewInstance.findViewById(R.id.edLoginUsername);
        edPassword = viewInstance.findViewById(R.id.edLoginPassword);

        tvForgotPassword.setOnClickListener(this);
        tvTerm.setOnClickListener(this);

        tvForgotPassword.setMovementMethod(LinkMovementMethod.getInstance());
        tvTerm.setMovementMethod(LinkMovementMethod.getInstance());

        btnLogin.setOnClickListener(this);
        relLoginWithGoogle.setOnClickListener(this);
        relLoginWithFacebook.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){
            case R.id.btnLogin:
                //do something here
                strUsername = edUsername.getText().toString().trim();
                strPassword = edPassword.getText().toString().trim();
                loginInstance.loginWithEmailAndPassword(strUsername, strPassword);

                break;
            case R.id.relLoginWithFacebook:
                //login with fb
                loginInstance.finishLoginActivity(IntentCode.RESULT_LOGIN_SUCCESSFUL, "Login with Facebook");
                break;
            case R.id.relLoginWithGoogle:
                //login with gg
                loginInstance.finishLoginActivity(IntentCode.RESULT_LOGIN_SUCCESSFUL, "Login with Google");
                break;
            case R.id.tvForgotPassword:
                Intent intentResetPassword = new Intent(getContext(), ResetPasswordActivity.class);
                startActivity(intentResetPassword);
                break;
            case R.id.tvTermPolicy:
                MyHelper.toast(getContext(), "This should open web browser to see term polycy!");
                break;
        }
    }
}